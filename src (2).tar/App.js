import React from 'react'
import Slides from './components/Sides'

function App() {
  return (
    <div className="App">
      <Slides />
    </div>
  )
}

export default App
